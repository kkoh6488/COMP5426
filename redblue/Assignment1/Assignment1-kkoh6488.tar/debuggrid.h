#ifndef DEBUGGRID_H
#define DEBUGGRID_H

void print_grid(int** grid, int height, int width);

void print_array(int* arr, int size);

#endif
