#ifndef REDBLUE_PROC
#define REDBLUE_PROC

void solveredturn(int **subgrid, int height, int width);

void solveblueturn(int **subgrid, int *botbuffer, int height, int width);

#endif
